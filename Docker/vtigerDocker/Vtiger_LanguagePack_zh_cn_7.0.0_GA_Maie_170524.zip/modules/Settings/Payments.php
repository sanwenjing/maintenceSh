<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * 简体中文语言包 - 支付
 * 版本: 6.1.0 
 * 作者: Maie | www.maie.name
 * 更新日期: 2014-08-30
 * All Rights Reserved.
 ************************************************************************************/

$languageStrings = array(
    'LBL_RIGHT_CLICK_COPY' => '右键单击并复制',
);

$jsLanguageStrings = array(
	'JS_DELETED_SUCCESSFULLY' => '删除成功',
	'JS_SAVED_SUCCESSFULLY' => '保存成功',
);	